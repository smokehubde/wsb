// Doesn't make sense to allow resizing the canvas lower than this.
export const minCanvasWidth = 240;
